﻿using System;
using System.Globalization;

namespace ConversorDeMoedas
{
	class Program
	{
		static void Main(string[] args)
		{
			CultureInfo CI = CultureInfo.InvariantCulture;

			Console.Write("Qual é a cotação do dólar?");
			ConversorDeMoedas.dolar = double.Parse(Console.ReadLine(), CI);
			Console.Write("Quantos dólares você vai comprar?");
			ConversorDeMoedas.real = double.Parse(Console.ReadLine(), CI);

			Console.WriteLine("Valor a ser pago em reais: " + ConversorDeMoedas.ValorAPagar().ToString("F2", CI));
		}
	}
}
