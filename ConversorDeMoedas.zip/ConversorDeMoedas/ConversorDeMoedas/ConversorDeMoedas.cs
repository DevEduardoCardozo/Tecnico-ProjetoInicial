﻿namespace ConversorDeMoedas
{
	class ConversorDeMoedas
	{
		public static double dolar, real, iof = 0.06;

		public static double ValorAPagar()
		{
			return real * dolar + (real * dolar) * iof;
		}
	}
}
